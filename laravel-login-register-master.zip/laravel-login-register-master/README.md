User login and registration in Laravel
========

A simple and basic system with user login and register feature using Laravel PHP Framework.

Blog Article: [Laravel: Login Register](http://blog.chapagain.com.np/laravel-login-register-beginner-tutorial/)
