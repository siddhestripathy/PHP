
@extends('layouts.master')

@section('title', $title)

@section('sidebar')
    @parent
    // you can add something here
@endsection

@section('content')	
	<h1>{{ $title }}</h1>
	
	<p>Middleware page !!</p>
		
@endsection
